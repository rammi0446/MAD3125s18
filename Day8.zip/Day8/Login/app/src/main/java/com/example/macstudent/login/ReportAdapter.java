package com.example.macstudent.login;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ReportAdapter extends BaseAdapter {
    LayoutInflater inflater;
    Context context;
    String[] carPlates={"ASD123","QWR123","ASD123"};
    String[] lots={"A","B","C"};
    String[] spots={"1","41","23"};
    String[] dateTime={"12-12-2018 12:12:12","12-12-18 13:12:12","12-12-18 10:10:10"};
    String[] amounts={"10","20","30"};
    ReportAdapter(Context context)
    {
        this.context=context;
        inflater=LayoutInflater.from(this.context);
    }

    @Override
    public int getCount() {
        return carPlates.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView=inflater.inflate(R.layout.list_report_item,null);

        TextView txtDateTime=convertView.findViewById(R.id.txtDateTime);
        txtDateTime.setText(dateTime[position]);
        TextView txtCarPlate=convertView.findViewById(R.id.txtCarPlate);
        txtCarPlate.setText(carPlates[position]);
        TextView txtAmount=convertView.findViewById(R.id.txtAmount);
        txtAmount.setText(amounts[position]);
        TextView txtlot=convertView.findViewById(R.id.txtLot);
        txtlot.setText(lots[position]);
        TextView txtspot=convertView.findViewById(R.id.txtSpot);
        txtspot.setText(spots[position]);
        return null;
    }
}
