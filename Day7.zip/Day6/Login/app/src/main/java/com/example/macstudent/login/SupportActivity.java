package com.example.macstudent.login;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SupportActivity extends AppCompatActivity implements View.OnClickListener{
    Button btnCall,btnSMS,btnEmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);
        btnCall=findViewById(R.id.btnCall);
        btnCall.setOnClickListener(this);
        btnSMS=findViewById(R.id.btnSMS);
        btnSMS.setOnClickListener(this);
        btnEmail=findViewById(R.id.btnEmail);
        btnEmail.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
       // if(v.getId()==btnCall.getId())
      //  {

     //   }else if(v.getId()==btnSMS.getId())
      //  {
      //
       // }else if(v.getId()==btnEmail.getId())
       // {

       // }
        switch(v.getId())
        {
            case R.id.btnCall:
                makeCall();
                break;
            case R.id.btnSMS:
                sendSMS();
                break;
            case R.id.btnEmail:
                sendEmail();
                break;
        }

    }
    private void makeCall()
    {
        Intent callIntent=new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:+16474000472"));

        if(ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(), "Call Permission Denied", Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(callIntent);
    }
    private void sendSMS()
    {
        Intent smsIntent=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:+16474000472"));
        smsIntent.putExtra("sms body","this is a text message");
        if(ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(), "sms Permission Denied", Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(smsIntent);
    }
    private void sendEmail()
    {
         Intent emailIntent=new Intent(Intent.ACTION_SEND);
         emailIntent.putExtra(Intent.EXTRA_EMAIL,new String [] {"rammi.0446@gmail.com","sagarsaini3993@gmail.com"});
            emailIntent.putExtra(Intent.EXTRA_SUBJECT,"Test Email");
            emailIntent.putExtra(Intent.EXTRA_TEXT,"This is text message feom meeeeee");
            emailIntent.setType("*/*");
            startActivity(Intent.createChooser(emailIntent,"select email account"));
    }
}
